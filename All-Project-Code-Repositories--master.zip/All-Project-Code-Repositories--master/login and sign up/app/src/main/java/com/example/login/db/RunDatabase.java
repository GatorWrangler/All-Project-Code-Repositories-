package com.example.login.db;

import androidx.room.RoomDatabase;

public abstract class RunDatabase extends RoomDatabase
{
 public abstract runDAO run_DAO();
}
