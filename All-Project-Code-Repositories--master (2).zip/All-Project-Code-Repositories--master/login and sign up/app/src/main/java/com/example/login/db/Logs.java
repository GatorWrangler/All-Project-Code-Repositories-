package com.example.login.db;

public class Logs {
}
