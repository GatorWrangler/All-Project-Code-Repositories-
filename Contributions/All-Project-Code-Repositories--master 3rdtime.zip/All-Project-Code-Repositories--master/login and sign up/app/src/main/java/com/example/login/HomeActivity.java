package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

//homepage(after login)
public class HomeActivity<button2> extends AppCompatActivity {
    private Button Btnmove;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Btnmove=findViewById(R.id.button2);
        Btnmove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTologs_view();
            }
            private void   moveTologs_view(){
                Intent intent = new Intent(HomeActivity.this, logs_view.class );
               startActivity(intent);
            }
        });


    }

//    private void setContentView(int activity_home) {
//    }
}