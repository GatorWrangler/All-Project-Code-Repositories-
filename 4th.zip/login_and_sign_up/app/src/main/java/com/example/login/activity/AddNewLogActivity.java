package com.example.login.activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.login.R;
import com.example.login.bean.LogBean;
import com.example.login.db.LogDataService;

import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AddNewLogActivity extends AppCompatActivity {
    public static final int ADD = 1002;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.difficulty_ra)
    RadioGroup difficulty_ra;

    @BindView(R.id.date)
    EditText date;
    @BindView(R.id.section)
    EditText section;
    @BindView(R.id.distance)
    EditText distance;
    private String difficulty;
    private String dateStr;
    private LogDataService logDataService;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_log);
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#f0f0f0"));
        }
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//左侧添加一个默认的返回图标
        getSupportActionBar().setHomeButtonEnabled(true); //设置返回键可用
        getSupportActionBar().setTitle(R.string.newlogs);
        initRadioGroup();
        logDataService = new LogDataService(this);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar mCalendar = Calendar.getInstance();
                int year = mCalendar.get(Calendar.YEAR);
                int month = mCalendar.get(Calendar.MONTH);
                int day = mCalendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog mDatePickerDialog = new DatePickerDialog(AddNewLogActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        month = month + 1;
                        StringBuilder builder = new StringBuilder();
                        builder.append(year).append("/");
                        builder.append(String.format("%02d", month)).append("/");
                        builder.append(String.format("%02d", dayOfMonth));
                        dateStr = builder.toString();
                        date.setText(dateStr);
                        Log.i("date", dateStr);
                    }

                }, year, month, day);
                mDatePickerDialog.show();

            }
        });
    }

    private void initRadioGroup() {
        String[] difficults = getResources().getStringArray(R.array.difficults);
        difficulty = difficults[0];
        difficulty_ra.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.easy_text:
                        difficulty = difficults[0];
                        break;
                    case R.id.medium_text:
                        difficulty = difficults[1];
                        break;
                    case R.id.difficult_text:
                        difficulty = difficults[2];
                        break;
                }

            }
        });
    }

    @OnClick(R.id.add)
    public void add(View v) {
        String dataStr = date.getText().toString().trim();
        String sectionStr = section.getText().toString().trim();
        String distanceStr = distance.getText().toString().trim();
        if (TextUtils.isEmpty(dataStr)) {
            Toast.makeText(this, getString(R.string.input_data), Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(sectionStr)) {
            Toast.makeText(this, getString(R.string.input_section), Toast.LENGTH_SHORT).show();
            return;
        }
        if (TextUtils.isEmpty(distanceStr)) {
            Toast.makeText(this, getString(R.string.input_distance), Toast.LENGTH_SHORT).show();
            return;
        }
        LogBean bean = new LogBean();
        bean.setDate(dataStr);
        bean.setSection(sectionStr);
        bean.setDistance(distanceStr);
        bean.setDifficulty(difficulty);
        logDataService.insertUser(bean);
        Intent intent = new Intent();
        intent.putExtra("add", true);
        setResult(AddNewLogActivity.ADD, intent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
            case android.R.id.home:
                finish();
                return true;

        }


        return super.onOptionsItemSelected(item);
    }


}
