package com.example.login.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.example.login.bean.LogBean;

import java.util.ArrayList;
import java.util.List;


/**
 * 表操作类
 *
 * @author x8.phoenix
 */

public class LogDataService {
    private static final String TAG = LogDataService.class.getName();
    private DBOpenHelper dbOpenHelper;

    public LogDataService(Context context) {
        dbOpenHelper = new DBOpenHelper(context);
    }

    // 增;
    public void insertUser(LogBean bean) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("insert into " + LogColumns.TABLE_NAME + "(" + LogColumns.DATE + "," + LogColumns.DISTANCE + "," + LogColumns.SECTION + "," + LogColumns.DIFFICULTY + ") values(?,?,?,?)", new Object[]{bean.getDate(), bean.getDistance(), bean.getSection(), bean.getDifficulty()});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        db.close();
    }


    // 删
    public void deleteUser(int  _id) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.execSQL("delete from " + LogColumns.TABLE_NAME + " where " + LogColumns._ID + "=?", new Object[]{_id});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        db.close(); // new
        // Object[]{_id}
    }


    //查询
    public List<LogBean> queryAll(String columns,String a) {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + LogColumns.TABLE_NAME + " order by " + columns + " " + a, null);
        if (cursor == null) {
            return null;
        } else {
            if (cursor.getCount() == 0) return null;
        }
        List<LogBean> userBeanList = new ArrayList<LogBean>();
        while (cursor.moveToNext()) {
            LogBean bean = new LogBean();
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String DATE = cursor.getString(cursor.getColumnIndex(LogColumns.DATE));
            String DISTANCE = cursor.getString(cursor.getColumnIndex(LogColumns.DISTANCE));
            String SECTION = cursor.getString(cursor.getColumnIndex(LogColumns.SECTION));
            String DIFFICULTY = cursor.getString(cursor.getColumnIndex(LogColumns.DIFFICULTY));
            bean._id = id;
            bean.setDate(DATE);
            bean.setDistance(DISTANCE);
            bean.setSection(SECTION);
            bean.setDifficulty(DIFFICULTY);
            userBeanList.add(bean);
        }
        cursor.close();
        return userBeanList;
    }

    //查询
    public List<LogBean> queryAll() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + LogColumns.TABLE_NAME, null);
        if (cursor == null) {
            return null;
        } else {
            if (cursor.getCount() == 0) return null;
        }
        List<LogBean> userBeanList = new ArrayList<LogBean>();
        while (cursor.moveToNext()) {
            LogBean bean = new LogBean();
            int id = cursor.getInt(cursor.getColumnIndex("_id"));
            String DATE = cursor.getString(cursor.getColumnIndex(LogColumns.DATE));
            String DISTANCE = cursor.getString(cursor.getColumnIndex(LogColumns.DISTANCE));
            String SECTION = cursor.getString(cursor.getColumnIndex(LogColumns.SECTION));
            String DIFFICULTY = cursor.getString(cursor.getColumnIndex(LogColumns.DIFFICULTY));
            bean._id = id;
            bean.setDate(DATE);
            bean.setDistance(DISTANCE);
            bean.setSection(SECTION);
            bean.setDifficulty(DIFFICULTY);
            userBeanList.add(bean);
        }
        cursor.close();
        return userBeanList;
    }



}
