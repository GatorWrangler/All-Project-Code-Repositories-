package com.example.login.adapter;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login.R;
import com.example.login.bean.LogBean;

import java.util.List;

public class LogsAdapter extends RecyclerView.Adapter<LogsAdapter.MyViewHolder> {

    private List<LogBean> datas;
    private Context mContext;
    private OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(int position, LogBean data);
    }

    public void setOnItemClickListener(OnItemClickListener l) {
        this.onItemClickListener = l;
    }

    public void setData(List<LogBean> datas) {
        this.datas = datas;
        notifyDataSetChanged();
    }

    //创建ViewHolder
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //实例化得到Item布局文件的View对象
        mContext = parent.getContext();
        View v = LayoutInflater.from(mContext).inflate(R.layout.item_log, parent, false);
        //返回MyViewHolder的对象
        return new MyViewHolder(v);
    }

    //绑定数据
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.id.setText(String.valueOf(datas.get(position)._id));
        holder.date.setText(datas.get(position).getDate());
        holder.distance.setText(datas.get(position).getDistance());
        holder.section.setText(datas.get(position).getSection());
        holder.difficulty.setText(datas.get(position).getDifficulty());

    }

    //返回Item的数量
    @Override
    public int getItemCount() {
        return datas == null ? 0 : datas.size();
    }

    //继承RecyclerView.ViewHolder抽象类的自定义ViewHolder
    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView id;
        TextView date;
        TextView distance;
        TextView section;
        TextView difficulty;

        MyViewHolder(View itemView) {
            super(itemView);
            id = itemView.findViewById(R.id.id);
            date = itemView.findViewById(R.id.date);
            distance = itemView.findViewById(R.id.distance);
            section = itemView.findViewById(R.id.section);
            difficulty = itemView.findViewById(R.id.difficulty);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListener != null)
                        onItemClickListener.onItemClick(getAdapterPosition(), datas.get(getAdapterPosition()));
                }
            });
        }
    }
}

