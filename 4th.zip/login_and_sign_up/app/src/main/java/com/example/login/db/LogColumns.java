package com.example.login.db;

import android.provider.BaseColumns;

/**
 * login 中的常量
 *
 * @author x8.phoenix
 */
public final class LogColumns implements BaseColumns {
    static final String TABLE_NAME = "log";
    //public static final String DEFAULT_SORT_ORDER = "level desc";
    static final String DATE = "date";
  public   static final String DISTANCE = "distance";
    static final String SECTION = "section";
    static final String DIFFICULTY = "difficulty";


}