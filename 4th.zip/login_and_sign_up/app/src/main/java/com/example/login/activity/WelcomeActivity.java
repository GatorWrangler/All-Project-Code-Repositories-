package com.example.login.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.login.R;
import com.example.login.utils.PreferencesUtils;
import com.example.login.utils.StatusBarUtils;

import butterknife.ButterKnife;
import butterknife.OnClick;

//WelcomePage(after login)
public class WelcomeActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StatusBarUtils.with(this).setColor(Color.parseColor("#DCDCDC")).init();
        setContentView(R.layout.activity_welcome);
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#05009688"));
        }

    }

    @OnClick({R.id.button2, R.id.button5})
    public void onClock(View view) {
        switch (view.getId()) {
            case R.id.button2:
                startActivity(new Intent(this, LogsActivity.class));
                break;
            case R.id.button5:
                startActivity(new Intent(this, LoginActivity.class));
                finish();
                break;
        }
    }


}