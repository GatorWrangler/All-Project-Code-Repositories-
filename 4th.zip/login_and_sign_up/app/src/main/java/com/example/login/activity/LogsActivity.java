package com.example.login.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.login.R;
import com.example.login.adapter.LogsAdapter;
import com.example.login.db.LogColumns;
import com.example.login.db.LogDataService;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LogsActivity extends AppCompatActivity {
    public static final int ADD = 1001;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.logs_view)
    RecyclerView logs_view;
    @BindView(R.id.no_date)
    TextView no_date;

    @BindView(R.id.id)
    TextView id;
    @BindView(R.id.distance)
    TextView distance;
    @BindView(R.id.title)
    View title;
    private LogsAdapter dbAdapter;
    private LogDataService logDataService;
    private boolean isDistanceDesc = false;
    private boolean isIDDesc = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logs);
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setNavigationBarColor(Color.parseColor("#f0f0f0"));
        }
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//左侧添加一个默认的返回图标
        getSupportActionBar().setHomeButtonEnabled(true); //设置返回键可用
        getSupportActionBar().setTitle(R.string.logs);
        initRecyclerView();
        init();
    }

    @OnClick({R.id.distance, R.id.id})
    public void distanceSort(View view) {
        switch (view.getId()) {
            case R.id.distance:
                setIcon(false, isIDDesc, id);
                setIcon(true, isDistanceDesc, distance);
                String a;
                if (isDistanceDesc) {
                    a = "desc";
                } else {
                    a = "asc";
                }
                dbAdapter.setData(logDataService.queryAll(LogColumns.DISTANCE, a));
                isDistanceDesc = !isDistanceDesc;
                isIDDesc = false;
                break;
            case R.id.id:
                setIcon(true, isIDDesc, id);
                setIcon(false, isDistanceDesc, distance);
                String b;
                if (isIDDesc) {
                    b = "desc";
                } else {
                    b = "asc";
                }
                dbAdapter.setData(logDataService.queryAll(LogColumns._ID, b));
                isIDDesc = !isIDDesc;
                isDistanceDesc = false;
                break;
        }

    }

    private void setIcon(boolean isShow, boolean isDesc, TextView textView) {
        if (isShow) {
            int id;
            if (isDesc) {
                id = R.drawable.down;
            } else {
                id = R.drawable.up;
            }
            Drawable drawable = getResources().getDrawable(id);
            drawable.setBounds(0, 0, 20, 20);
            textView.setCompoundDrawables(null, null, drawable, null);
        } else {
            textView.setCompoundDrawables(null, null, null, null);
        }
    }

    //init RecyclerView
    private void initRecyclerView() {

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        logs_view.setLayoutManager(linearLayoutManager);
        dbAdapter = new LogsAdapter();
        logs_view.setAdapter(dbAdapter);

        logDataService = new LogDataService(this);

    }

    private void init() {
        dbAdapter.setData(logDataService.queryAll(LogColumns._ID, "asc"));
        if (dbAdapter.getItemCount() == 0) {
            title.setVisibility(View.GONE);
            no_date.setVisibility(View.VISIBLE);
        } else {
            no_date.setVisibility(View.GONE);
            title.setVisibility(View.VISIBLE);
        }


        setIcon(true, isIDDesc, id);
        setIcon(false, isDistanceDesc, distance);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == AddNewLogActivity.ADD) {
            if (requestCode == LogsActivity.ADD) {
                boolean isAdd = data.getBooleanExtra("add", false);
                Log.i("isAdd", "isAdd=" + isAdd);
                if (isAdd)
                    init();
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_logs, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
            case android.R.id.home:
                finish();
                return true;
            case R.id.action_settings:
                startActivityForResult(new Intent(this, AddNewLogActivity.class), LogsActivity.ADD);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }


}
