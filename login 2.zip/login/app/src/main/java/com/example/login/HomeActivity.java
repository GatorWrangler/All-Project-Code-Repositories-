package com.example.login;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

//主页 登陆之后的页面
public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

}